#!/usr/bin/env python3
"""Convert the DXT3-compressed BLP2 atlas bundled with TinyPad to PNG."""

import struct
import sys
import zlib
from pathlib import Path


def rgb565(value):
    red = ((value >> 11) & 31) * 255 // 31
    green = ((value >> 5) & 63) * 255 // 63
    blue = (value & 31) * 255 // 31
    return red, green, blue


def decode_dxt3(payload, width, height):
    pixels = bytearray(width * height * 4)
    offset = 0
    for block_y in range((height + 3) // 4):
        for block_x in range((width + 3) // 4):
            alpha_bits = int.from_bytes(payload[offset:offset + 8], "little")
            color_0, color_1, color_bits = struct.unpack_from("<HHI", payload, offset + 8)
            offset += 16

            c0 = rgb565(color_0)
            c1 = rgb565(color_1)
            colors = (
                c0,
                c1,
                tuple((2 * c0[i] + c1[i]) // 3 for i in range(3)),
                tuple((c0[i] + 2 * c1[i]) // 3 for i in range(3)),
            )

            for pixel in range(16):
                x = block_x * 4 + pixel % 4
                y = block_y * 4 + pixel // 4
                if x >= width or y >= height:
                    continue
                color = colors[(color_bits >> (pixel * 2)) & 3]
                alpha = ((alpha_bits >> (pixel * 4)) & 15) * 17
                target = (y * width + x) * 4
                pixels[target:target + 4] = bytes((*color, alpha))
    return pixels


def png_chunk(name, payload):
    return struct.pack(">I", len(payload)) + name + payload + struct.pack(">I", zlib.crc32(name + payload) & 0xFFFFFFFF)


def write_png(path, pixels, width, height):
    scanlines = bytearray()
    stride = width * 4
    for y in range(height):
        scanlines.append(0)
        scanlines.extend(pixels[y * stride:(y + 1) * stride])
    png = b"\x89PNG\r\n\x1a\n"
    png += png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
    png += png_chunk(b"IDAT", zlib.compress(bytes(scanlines), 9))
    png += png_chunk(b"IEND", b"")
    path.write_bytes(png)


def main(source, target):
    data = Path(source).read_bytes()
    if data[:4] != b"BLP2":
        raise SystemExit("Only BLP2 files are supported")
    encoding, alpha_depth, alpha_encoding = data[8], data[9], data[10]
    width, height = struct.unpack_from("<II", data, 12)
    mip_offset = struct.unpack_from("<I", data, 20)[0]
    mip_size = struct.unpack_from("<I", data, 84)[0]
    if (encoding, alpha_depth, alpha_encoding) != (2, 8, 1):
        raise SystemExit(f"Expected DXT3 BLP2, got encoding tuple {(encoding, alpha_depth, alpha_encoding)}")
    pixels = decode_dxt3(data[mip_offset:mip_offset + mip_size], width, height)
    write_png(Path(target), pixels, width, height)
    print(f"Converted {width}x{height} BLP2 atlas to {target}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: convert_blp.py source.blp target.png")
    main(sys.argv[1], sys.argv[2])
