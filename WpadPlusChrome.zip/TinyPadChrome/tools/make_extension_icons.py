#!/usr/bin/env python3
"""Extract the TinyPad note button from the generated atlas for Chrome icons."""

import struct
import zlib
from pathlib import Path


def chunks(data):
    offset = 8
    while offset < len(data):
        length = struct.unpack_from(">I", data, offset)[0]
        name = data[offset + 4:offset + 8]
        payload = data[offset + 8:offset + 8 + length]
        yield name, payload
        offset += length + 12


def read_rgba(path):
    data = path.read_bytes()
    parsed = list(chunks(data))
    ihdr = next(payload for name, payload in parsed if name == b"IHDR")
    width, height, depth, color, _, _, _ = struct.unpack(">IIBBBBB", ihdr)
    if (depth, color) != (8, 6):
        raise ValueError("Expected an 8-bit RGBA PNG")
    raw = zlib.decompress(b"".join(payload for name, payload in parsed if name == b"IDAT"))
    stride = width * 4
    rows = []
    for y in range(height):
        start = y * (stride + 1)
        if raw[start] != 0:
            raise ValueError("The TinyPad-generated atlas should use filter type 0")
        rows.append(raw[start + 1:start + 1 + stride])
    return width, height, b"".join(rows)


def chunk(name, payload):
    return struct.pack(">I", len(payload)) + name + payload + struct.pack(">I", zlib.crc32(name + payload) & 0xFFFFFFFF)


def write_rgba(path, width, height, pixels):
    raw = bytearray()
    stride = width * 4
    for y in range(height):
        raw.append(0)
        raw.extend(pixels[y * stride:(y + 1) * stride])
    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    png += chunk(b"IEND", b"")
    path.write_bytes(png)


def nearest_resize(source, source_size, target_size):
    target = bytearray(target_size * target_size * 4)
    for y in range(target_size):
        sy = min(source_size - 1, y * source_size // target_size)
        for x in range(target_size):
            sx = min(source_size - 1, x * source_size // target_size)
            src = (sy * source_size + sx) * 4
            dst = (y * target_size + x) * 4
            target[dst:dst + 4] = source[src:src + 4]
    return target


root = Path(__file__).resolve().parents[1]
width, height, atlas = read_rgba(root / "assets" / "Buttons.png")
if width < 32 or height < 32:
    raise SystemExit("TinyPad atlas is unexpectedly small")

cell = bytearray(32 * 32 * 4)
for y in range(32):
    cell[y * 128:(y + 1) * 128] = atlas[(y * width) * 4:(y * width + 32) * 4]

icon_dir = root / "icons"
icon_dir.mkdir(exist_ok=True)
for size in (16, 32, 48, 128):
    pixels = cell if size == 32 else nearest_resize(cell, 32, size)
    write_rgba(icon_dir / f"icon-{size}.png", size, size, pixels)
    print(f"Created icon-{size}.png")
