(function () {
  "use strict";

  const STORAGE_KEY = "tinypad.chrome.v1";
  const FONT_OPTIONS = [
    { family: 'Georgia, "Times New Roman", serif', size: "19px", names: { ru: "Классический · 19", en: "Classic · 19" } },
    { family: 'Georgia, "Times New Roman", serif', size: "22px", names: { ru: "Классический · 22", en: "Classic · 22" } },
    { family: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', size: "17px", names: { ru: "Современный · 17", en: "Modern · 17" } },
    { family: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', size: "20px", names: { ru: "Современный · 20", en: "Modern · 20" } },
    { family: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace', size: "16px", names: { ru: "Моноширинный · 16", en: "Monospace · 16" } },
    { family: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace', size: "19px", names: { ru: "Моноширинный · 19", en: "Monospace · 19" } }
  ];

  const LEGACY_WELCOME_TEXT = `Добро пожаловать в TinyPad для Chrome.

Это боковая панель по мотивам аддона для World of Warcraft 3.3.5.

Возможности:
— отдельные страницы заметок;
— автоматическое сохранение;
— поиск по всем страницам;
— закладки;
— отмена и повтор изменений;
— перестановка страниц с Shift;
— смена шрифта;
— импорт и экспорт резервной копии.

Подсказка: удерживайте Shift и нажимайте стрелки страниц, чтобы менять их порядок.`;

  const WELCOME_TEXTS = {
    ru: `Добро пожаловать в Wpad+ для Chrome.

Это боковая панель-блокнот по мотивам World of Warcraft.

Возможности:
— отдельные страницы заметок;
— автоматическое сохранение;
— поиск по всем страницам;
— закладки;
— отмена и повтор изменений;
— перестановка страниц с Shift;
— смена шрифта;
— импорт и экспорт резервной копии.

Подсказка: удерживайте Shift и нажимайте стрелки страниц, чтобы менять их порядок.`,
    en: `Welcome to Wpad+ for Chrome.

This side-panel notebook is inspired by World of Warcraft.

Features:
— separate note pages;
— automatic saving;
— search across all pages;
— bookmarks;
— undo and redo;
— rearrange pages with Shift;
— font switching;
— backup import and export.

Tip: hold Shift while pressing the page arrows to rearrange pages.`
  };

  const WELCOME_BOOKMARKS = {
    ru: "Знакомство с Wpad+",
    en: "Welcome to Wpad+"
  };

  const I18N = {
    ru: {
      title: "Wpad+ — боковая панель",
      desktop: "Рабочий стол Wpad+",
      pages: "Страницы",
      history: "История изменений",
      navigation: "Навигация по страницам",
      tools: "Инструменты",
      newPage: "Новая страница",
      newPageTip: "Новая страница · ⇧ — вставить после текущей",
      deletePage: "Удалить страницу",
      undo: "Отменить",
      undoTip: "Отменить · ⌘/Ctrl + Z",
      redo: "Повторить",
      redoTip: "Повторить · ⇧⌘/Ctrl + Z",
      firstPage: "Первая страница",
      firstPageTip: "Первая · ⇧ — переместить в начало",
      previousPage: "Предыдущая страница",
      previousPageTip: "Назад · ⇧ — поменять местами",
      nextPage: "Следующая страница",
      nextPageTip: "Вперёд · ⇧ — поменять местами",
      lastPage: "Последняя страница",
      lastPageTip: "Последняя · ⇧ — переместить в конец",
      goToPage: "Перейти к странице",
      pageTip: "Страница {current} из {total}",
      showTools: "Показать инструменты",
      hideTools: "Скрыть инструменты",
      search: "Поиск",
      searchTip: "Поиск · ⌘/Ctrl + F",
      bookmarks: "Закладки",
      bookmarksTip: "Развернуть закладки",
      font: "Сменить шрифт",
      settings: "Файл и настройки",
      settingsTip: "Развернуть файл и настройки",
      searchPanel: "Поиск по страницам",
      searchPlaceholder: "Поиск по всем страницам…",
      searchEmpty: "Введите текст",
      searchFound: "Найдено: {count}",
      searchNone: "Нет совпадений",
      findNext: "Найти далее",
      closeSearch: "Закрыть поиск",
      editor: "Текст текущей страницы",
      saved: " Сохранено",
      saving: " Сохранение…",
      saveError: " Ошибка сохранения",
      shortcut: "Alt + ← → — листать",
      quickJump: "Быстрый переход",
      closeBookmarks: "Закрыть закладки",
      bookmarkPlaceholder: "Название текущей страницы",
      bookmarkName: "Название закладки",
      save: "Сохранить",
      removeBookmark: "Удалить закладку текущей страницы",
      noBookmarks: "Закладок пока нет",
      export: "Экспорт",
      exportHint: "Сохранить резервную копию JSON",
      import: "Импорт",
      importHint: "Загрузить резервную копию",
      pageAsText: "Страница как TXT",
      pageAsTextHint: "Скачать текущую заметку",
      language: "Язык",
      languageHint: "Язык интерфейса",
      reset: "Вернуть окно в центр",
      resetHint: "Сбросить положение и размер",
      dialogNavigation: "Навигация",
      enterPage: "Введите номер страницы.",
      availablePages: "Доступно: от 1 до {total}.",
      enterRange: "Введите число от 1 до {total}.",
      cancel: "Отмена",
      go: "Перейти",
      pageInserted: "Страница вставлена после текущей",
      pageCreated: "Создана новая страница",
      deleteConfirm: "Удалить страницу {page}? Это действие нельзя отменить.",
      pageDeleted: "Страница удалена",
      pageMoved: "Страница перемещена: {page}",
      matchOnPage: "Совпадение на странице {page}",
      enterBookmark: "Введите название закладки",
      bookmarkSaved: "Закладка сохранена",
      bookmarkRemoved: "Закладка удалена",
      fontChanged: "Шрифт: {font}",
      backupCreated: "Резервная копия создана",
      pageSavedText: "Страница сохранена как TXT",
      replaceImport: "Заменить текущие заметки импортом ({count} {pages})?",
      backupLoaded: "Резервная копия загружена",
      invalidBackup: "Файл не похож на резервную копию Wpad+",
      windowReset: "Окно возвращено в центр",
      allSaved: "Все изменения сохранены",
      saveFailed: "Не удалось сохранить данные в браузере",
      languageChanged: "Язык изменён",
      pageFile: "страница-{page}"
    },
    en: {
      title: "Wpad+ — side panel",
      desktop: "Wpad+ workspace",
      pages: "Pages",
      history: "Edit history",
      navigation: "Page navigation",
      tools: "Tools",
      newPage: "New page",
      newPageTip: "New page · ⇧ — insert after current",
      deletePage: "Delete page",
      undo: "Undo",
      undoTip: "Undo · ⌘/Ctrl + Z",
      redo: "Redo",
      redoTip: "Redo · ⇧⌘/Ctrl + Z",
      firstPage: "First page",
      firstPageTip: "First · ⇧ — move to beginning",
      previousPage: "Previous page",
      previousPageTip: "Back · ⇧ — swap pages",
      nextPage: "Next page",
      nextPageTip: "Forward · ⇧ — swap pages",
      lastPage: "Last page",
      lastPageTip: "Last · ⇧ — move to end",
      goToPage: "Go to page",
      pageTip: "Page {current} of {total}",
      showTools: "Show tools",
      hideTools: "Hide tools",
      search: "Search",
      searchTip: "Search · ⌘/Ctrl + F",
      bookmarks: "Bookmarks",
      bookmarksTip: "Expand bookmarks",
      font: "Change font",
      settings: "File & settings",
      settingsTip: "Expand file and settings",
      searchPanel: "Search pages",
      searchPlaceholder: "Search all pages…",
      searchEmpty: "Enter text",
      searchFound: "Found: {count}",
      searchNone: "No matches",
      findNext: "Find next",
      closeSearch: "Close search",
      editor: "Current page text",
      saved: " Saved",
      saving: " Saving…",
      saveError: " Save error",
      shortcut: "Alt + ← → — navigate",
      quickJump: "Quick jump",
      closeBookmarks: "Close bookmarks",
      bookmarkPlaceholder: "Current page title",
      bookmarkName: "Bookmark name",
      save: "Save",
      removeBookmark: "Remove bookmark from current page",
      noBookmarks: "No bookmarks yet",
      export: "Export",
      exportHint: "Save a JSON backup",
      import: "Import",
      importHint: "Load a backup",
      pageAsText: "Page as TXT",
      pageAsTextHint: "Download the current note",
      language: "Language",
      languageHint: "Application interface",
      reset: "Center the window",
      resetHint: "Reset position and size",
      dialogNavigation: "Navigation",
      enterPage: "Enter a page number.",
      availablePages: "Available: 1 to {total}.",
      enterRange: "Enter a number from 1 to {total}.",
      cancel: "Cancel",
      go: "Go",
      pageInserted: "Page inserted after the current page",
      pageCreated: "New page created",
      deleteConfirm: "Delete page {page}? This action cannot be undone.",
      pageDeleted: "Page deleted",
      pageMoved: "Page moved: {page}",
      matchOnPage: "Match found on page {page}",
      enterBookmark: "Enter a bookmark name",
      bookmarkSaved: "Bookmark saved",
      bookmarkRemoved: "Bookmark removed",
      fontChanged: "Font: {font}",
      backupCreated: "Backup created",
      pageSavedText: "Page saved as TXT",
      replaceImport: "Replace the current notes with the import ({count} {pages})?",
      backupLoaded: "Backup loaded",
      invalidBackup: "This file does not look like a Wpad+ backup",
      windowReset: "Window returned to center",
      allSaved: "All changes saved",
      saveFailed: "Could not save data in the browser",
      languageChanged: "Language changed",
      pageFile: "page-{page}"
    }
  };

  const $ = (selector) => document.querySelector(selector);
  const elements = {
    window: $("#notepadWindow"),
    dragHandle: $("#dragHandle"),
    editor: $("#editor"),
    newPage: $("#newPage"),
    deletePage: $("#deletePage"),
    undo: $("#undo"),
    redo: $("#redo"),
    first: $("#firstPage"),
    previous: $("#previousPage"),
    next: $("#nextPage"),
    last: $("#lastPage"),
    pageCounter: $("#pageCounter"),
    toolbarExpand: $("#toolbarExpand"),
    toolbarTools: $("#toolbarTools"),
    searchToggle: $("#searchToggle"),
    searchPanel: $("#searchPanel"),
    searchInput: $("#searchInput"),
    searchResult: $("#searchResult"),
    searchNext: $("#searchNext"),
    searchClose: $("#searchClose"),
    bookmarkToggle: $("#bookmarkToggle"),
    bookmarkPopover: $("#bookmarkPopover"),
    bookmarkClose: $("#bookmarkClose"),
    bookmarkForm: $("#bookmarkForm"),
    bookmarkTitle: $("#bookmarkTitle"),
    bookmarkList: $("#bookmarkList"),
    removeBookmark: $("#removeBookmark"),
    fontCycle: $("#fontCycle"),
    moreToggle: $("#moreToggle"),
    morePopover: $("#morePopover"),
    exportNotes: $("#exportNotes"),
    exportText: $("#exportText"),
    importNotes: $("#importNotes"),
    importFile: $("#importFile"),
    languageSelect: $("#languageSelect"),
    languageLabel: $("#languageLabel"),
    languageHint: $("#languageHint"),
    resetPosition: $("#resetPosition"),
    saveState: $("#saveState"),
    pageDetails: $("#pageDetails"),
    toast: $("#toast"),
    pageDialog: $("#pageDialog"),
    pageDialogForm: $("#pageDialogForm"),
    pageDialogHint: $("#pageDialogHint"),
    pageNumberInput: $("#pageNumberInput"),
    pageDialogCancel: $("#pageDialogCancel"),
    pageDialogGo: $("#pageDialogGo")
  };

  let state = loadState();
  let saveTimer = null;
  let toastTimer = null;
  let historyTimer = 0;
  const histories = new Map();

  function translate(key, variables = {}, language = "ru") {
    const template = I18N[language]?.[key] ?? I18N.ru[key] ?? key;
    return template.replace(/\{(\w+)\}/g, (_, name) => String(variables[name] ?? ""));
  }

  function tr(key, variables = {}) {
    return translate(key, variables, state.language);
  }

  function preferredLanguage() {
    return navigator.language.toLocaleLowerCase().startsWith("ru") ? "ru" : "en";
  }

  function migrateWelcomePage(page, language) {
    const knownTexts = [LEGACY_WELCOME_TEXT, WELCOME_TEXTS.ru, WELCOME_TEXTS.en];
    const knownBookmarks = ["Знакомство с TinyPad", WELCOME_BOOKMARKS.ru, WELCOME_BOOKMARKS.en];
    const text = knownTexts.includes(page.text) ? WELCOME_TEXTS[language] : page.text;
    const bookmark = knownBookmarks.includes(page.bookmark) ? WELCOME_BOOKMARKS[language] : page.bookmark;
    return { ...page, text, bookmark };
  }

  function createId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return `page-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function defaultState(language = preferredLanguage()) {
    return {
      version: 1,
      pages: [{ id: createId(), text: WELCOME_TEXTS[language], bookmark: WELCOME_BOOKMARKS[language] }],
      current: 0,
      fontIndex: 0,
      language,
      windowRect: null
    };
  }

  function normalizeState(candidate) {
    if (!candidate || !Array.isArray(candidate.pages) || candidate.pages.length === 0) return defaultState();
    const language = candidate.language === "en" || candidate.language === "ru" ? candidate.language : preferredLanguage();
    const pages = candidate.pages
      .filter((page) => page && typeof page === "object")
      .map((page) => ({
        id: typeof page.id === "string" ? page.id : createId(),
        text: typeof page.text === "string" ? page.text : "",
        bookmark: typeof page.bookmark === "string" ? page.bookmark.slice(0, 80) : ""
      }))
      .map((page) => migrateWelcomePage(page, language));
    if (!pages.length) pages.push({ id: createId(), text: "", bookmark: "" });
    return {
      version: 1,
      pages,
      current: Math.max(0, Math.min(Number(candidate.current) || 0, pages.length - 1)),
      fontIndex: Math.max(0, Math.min(Number(candidate.fontIndex) || 0, FONT_OPTIONS.length - 1)),
      language,
      windowRect: isValidRect(candidate.windowRect) ? candidate.windowRect : null
    };
  }

  function isValidRect(rect) {
    return rect && ["left", "top", "width", "height"].every((key) => Number.isFinite(Number(rect[key])));
  }

  function loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? normalizeState(JSON.parse(saved)) : defaultState();
    } catch (error) {
      console.warn("Wpad+: не удалось прочитать сохранение", error);
      return defaultState();
    }
  }

  function persist(immediate) {
    elements.saveState.classList.add("saving");
    elements.saveState.lastChild.textContent = tr("saving");
    window.clearTimeout(saveTimer);

    const write = () => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        elements.saveState.classList.remove("saving");
        elements.saveState.lastChild.textContent = tr("saved");
      } catch (error) {
        elements.saveState.lastChild.textContent = tr("saveError");
        showToast(tr("saveFailed"));
      }
    };

    if (immediate) write();
    else saveTimer = window.setTimeout(write, 320);
  }

  function currentPage() {
    return state.pages[state.current];
  }

  function historyFor(pageId) {
    if (!histories.has(pageId)) histories.set(pageId, { undo: [], redo: [] });
    return histories.get(pageId);
  }

  function pluralizePages(count) {
    if (state.language === "en") return count === 1 ? "page" : "pages";
    const mod10 = count % 10;
    const mod100 = count % 100;
    if (mod10 === 1 && mod100 !== 11) return "страница";
    if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) return "страницы";
    return "страниц";
  }

  function setControlText(element, label, tip = label) {
    element.setAttribute("aria-label", label);
    if (element.hasAttribute("data-tip")) element.dataset.tip = tip;
  }

  function setMenuText(element, title, hint) {
    element.querySelector("strong").textContent = title;
    element.querySelector("small").textContent = hint;
  }

  function applyLanguage() {
    const toolsOpen = elements.dragHandle.classList.contains("tools-open");
    document.documentElement.lang = state.language;
    document.title = tr("title");
    $(".desktop").setAttribute("aria-label", tr("desktop"));
    elements.window.setAttribute("aria-label", "Wpad+");
    elements.newPage.closest(".tool-group").setAttribute("aria-label", tr("pages"));
    elements.undo.closest(".tool-group").setAttribute("aria-label", tr("history"));
    elements.first.closest(".page-nav").setAttribute("aria-label", tr("navigation"));
    elements.toolbarTools.setAttribute("aria-label", tr("tools"));

    setControlText(elements.newPage, tr("newPage"), tr("newPageTip"));
    setControlText(elements.deletePage, tr("deletePage"));
    setControlText(elements.undo, tr("undo"), tr("undoTip"));
    setControlText(elements.redo, tr("redo"), tr("redoTip"));
    setControlText(elements.first, tr("firstPage"), tr("firstPageTip"));
    setControlText(elements.previous, tr("previousPage"), tr("previousPageTip"));
    setControlText(elements.next, tr("nextPage"), tr("nextPageTip"));
    setControlText(elements.last, tr("lastPage"), tr("lastPageTip"));
    setControlText(elements.pageCounter, tr("goToPage"), tr("pageTip", { current: state.current + 1, total: state.pages.length }));
    setControlText(elements.toolbarExpand, tr(toolsOpen ? "hideTools" : "showTools"));
    setControlText(elements.searchToggle, tr("search"), tr("searchTip"));
    setControlText(elements.bookmarkToggle, tr("bookmarks"), tr("bookmarksTip"));
    setControlText(elements.fontCycle, tr("font"));
    setControlText(elements.moreToggle, tr("settings"), tr("settingsTip"));

    elements.searchPanel.setAttribute("aria-label", tr("searchPanel"));
    elements.searchInput.placeholder = tr("searchPlaceholder");
    elements.searchNext.textContent = tr("findNext");
    elements.searchClose.setAttribute("aria-label", tr("closeSearch"));
    elements.editor.setAttribute("aria-label", tr("editor"));
    $(".shortcut-hint").textContent = tr("shortcut");

    elements.bookmarkPopover.setAttribute("aria-label", tr("bookmarks"));
    $("#bookmarkPopover .eyebrow").textContent = tr("bookmarks");
    $("#bookmarkPopover h2").textContent = tr("quickJump");
    elements.bookmarkClose.setAttribute("aria-label", tr("closeBookmarks"));
    elements.bookmarkTitle.placeholder = tr("bookmarkPlaceholder");
    elements.bookmarkTitle.setAttribute("aria-label", tr("bookmarkName"));
    $("#bookmarkForm .panel-button").textContent = tr("save");
    elements.removeBookmark.textContent = tr("removeBookmark");

    elements.morePopover.setAttribute("aria-label", tr("settings"));
    $("#morePopover h2").textContent = tr("settings");
    setMenuText(elements.exportNotes, tr("export"), tr("exportHint"));
    setMenuText(elements.importNotes, tr("import"), tr("importHint"));
    setMenuText(elements.exportText, tr("pageAsText"), tr("pageAsTextHint"));
    setMenuText(elements.resetPosition, tr("reset"), tr("resetHint"));
    elements.languageLabel.textContent = tr("language");
    elements.languageHint.textContent = tr("languageHint");
    elements.languageSelect.setAttribute("aria-label", tr("languageHint"));
    elements.languageSelect.value = state.language;

    $("#pageDialog .eyebrow").textContent = tr("dialogNavigation");
    $("#pageDialog h2").textContent = tr("goToPage");
    elements.pageDialogHint.textContent = tr("enterPage");
    elements.pageDialogCancel.textContent = tr("cancel");
    elements.pageDialogGo.textContent = tr("go");

    elements.saveState.lastChild.textContent = tr(elements.saveState.classList.contains("saving") ? "saving" : "saved");
    updateStatus();
    updateSearchCount();
    if (!elements.bookmarkPopover.hidden) renderBookmarks();
  }

  function changeLanguage(language) {
    if (language !== "ru" && language !== "en") return;
    state.pages = state.pages.map((page) => migrateWelcomePage(page, language));
    state.language = language;
    applyLanguage();
    render();
    persist(true);
    showToast(tr("languageChanged"));
  }

  function render(options = {}) {
    const page = currentPage();
    if (!options.keepEditor) {
      elements.editor.value = page.text;
      elements.editor.scrollTop = 0;
    }
    elements.pageCounter.textContent = String(state.current + 1);
    elements.pageCounter.dataset.tip = tr("pageTip", { current: state.current + 1, total: state.pages.length });
    elements.first.disabled = state.current === 0;
    elements.previous.disabled = state.current === 0;
    elements.next.disabled = state.current === state.pages.length - 1;
    elements.last.disabled = state.current === state.pages.length - 1;
    elements.deletePage.disabled = state.pages.length === 1 && page.text.length === 0;
    applyFont();
    updateHistoryButtons();
    updateStatus();
    updateSearchCount();
    if (!elements.bookmarkPopover.hidden) renderBookmarks();
  }

  function updateStatus() {
    const length = elements.editor.value.length;
    const locale = state.language === "ru" ? "ru-RU" : "en-US";
    const characters = state.language === "ru" ? "симв." : length === 1 ? "character" : "characters";
    elements.pageDetails.textContent = `${state.pages.length} ${pluralizePages(state.pages.length)} · ${length.toLocaleString(locale)} ${characters}`;
  }

  function applyFont() {
    const option = FONT_OPTIONS[state.fontIndex];
    document.documentElement.style.setProperty("--font-editor", option.family);
    document.documentElement.style.setProperty("--editor-size", option.size);
  }

  function updateHistoryButtons() {
    const history = historyFor(currentPage().id);
    elements.undo.disabled = history.undo.length === 0;
    elements.redo.disabled = history.redo.length === 0;
  }

  function setCurrentText(value, trackHistory = true) {
    const page = currentPage();
    if (page.text === value) return;
    if (trackHistory) {
      const now = Date.now();
      const history = historyFor(page.id);
      const previous = page.text;
      if (now - historyTimer > 700 || history.undo.length === 0) {
        history.undo.push(previous);
        if (history.undo.length > 100) history.undo.shift();
      }
      history.redo.length = 0;
      historyTimer = now;
    }
    page.text = value;
    updateHistoryButtons();
    updateStatus();
    updateSearchCount();
    persist(false);
  }

  function goToPage(index, focusEditor = true) {
    const nextIndex = Math.max(0, Math.min(index, state.pages.length - 1));
    state.current = nextIndex;
    historyTimer = 0;
    render();
    persist(false);
    closePopovers();
    if (focusEditor) elements.editor.focus();
  }

  function addPage(afterCurrent) {
    const newPage = { id: createId(), text: "", bookmark: "" };
    if (afterCurrent) {
      state.pages.splice(state.current + 1, 0, newPage);
      state.current += 1;
    } else {
      state.pages.push(newPage);
      state.current = state.pages.length - 1;
    }
    render();
    persist(true);
    elements.editor.focus();
    showToast(tr(afterCurrent ? "pageInserted" : "pageCreated"));
  }

  function deleteCurrentPage() {
    const page = currentPage();
    if (page.text.trim() && !window.confirm(tr("deleteConfirm", { page: state.current + 1 }))) return;
    histories.delete(page.id);
    state.pages.splice(state.current, 1);
    if (!state.pages.length) state.pages.push({ id: createId(), text: "", bookmark: "" });
    state.current = Math.min(state.current, state.pages.length - 1);
    render();
    persist(true);
    showToast(tr("pageDeleted"));
  }

  function moveCurrent(target) {
    const from = state.current;
    const to = Math.max(0, Math.min(target, state.pages.length - 1));
    if (from === to) return;
    const [page] = state.pages.splice(from, 1);
    state.pages.splice(to, 0, page);
    state.current = to;
    render();
    persist(true);
    showToast(tr("pageMoved", { page: to + 1 }));
  }

  function navigateWithShift(event, normalTarget, shiftedTarget) {
    if (event.shiftKey) moveCurrent(shiftedTarget);
    else goToPage(normalTarget);
  }

  function undo() {
    const history = historyFor(currentPage().id);
    if (!history.undo.length) return;
    history.redo.push(currentPage().text);
    currentPage().text = history.undo.pop();
    elements.editor.value = currentPage().text;
    historyTimer = 0;
    updateHistoryButtons();
    updateStatus();
    updateSearchCount();
    persist(false);
  }

  function redo() {
    const history = historyFor(currentPage().id);
    if (!history.redo.length) return;
    history.undo.push(currentPage().text);
    currentPage().text = history.redo.pop();
    elements.editor.value = currentPage().text;
    historyTimer = 0;
    updateHistoryButtons();
    updateStatus();
    updateSearchCount();
    persist(false);
  }

  function setSearchOpen(open) {
    if (open) setToolbarToolsOpen(true);
    elements.searchPanel.hidden = !open;
    elements.searchToggle.classList.toggle("active", open);
    if (open) {
      closePopovers();
      window.setTimeout(() => {
        elements.searchInput.focus();
        elements.searchInput.select();
      }, 0);
    }
  }

  function setToolbarToolsOpen(open) {
    elements.dragHandle.classList.toggle("tools-open", open);
    elements.toolbarTools.inert = !open;
    elements.toolbarTools.setAttribute("aria-hidden", String(!open));
    elements.toolbarExpand.setAttribute("aria-expanded", String(open));
    elements.toolbarExpand.setAttribute("aria-label", tr(open ? "hideTools" : "showTools"));
    elements.toolbarExpand.dataset.tip = tr(open ? "hideTools" : "showTools");
    if (!open) {
      closePopovers();
      setSearchOpen(false);
    }
  }

  function updateSearchCount() {
    const locale = state.language === "ru" ? "ru-RU" : "en-US";
    const query = elements.searchInput.value.trim().toLocaleLowerCase(locale);
    if (!query) {
      elements.searchResult.textContent = tr("searchEmpty");
      elements.searchNext.disabled = true;
      return;
    }
    const count = state.pages.filter((page) => page.text.toLocaleLowerCase(locale).includes(query)).length;
    elements.searchResult.textContent = count ? tr("searchFound", { count }) : tr("searchNone");
    elements.searchNext.disabled = count === 0;
  }

  function findNext() {
    const locale = state.language === "ru" ? "ru-RU" : "en-US";
    const query = elements.searchInput.value.trim().toLocaleLowerCase(locale);
    if (!query) return;
    for (let offset = 1; offset <= state.pages.length; offset += 1) {
      const index = (state.current + offset) % state.pages.length;
      if (state.pages[index].text.toLocaleLowerCase(locale).includes(query)) {
        state.current = index;
        render();
        setSearchOpen(true);
        highlightSearch(query);
        showToast(tr("matchOnPage", { page: index + 1 }));
        return;
      }
    }
  }

  function highlightSearch(query) {
    const locale = state.language === "ru" ? "ru-RU" : "en-US";
    const text = elements.editor.value.toLocaleLowerCase(locale);
    const start = text.indexOf(query);
    if (start >= 0) {
      elements.editor.focus();
      elements.editor.setSelectionRange(start, start + query.length);
    }
  }

  function closePopovers(except) {
    if (except !== "bookmark") {
      elements.bookmarkPopover.hidden = true;
      elements.bookmarkToggle.classList.remove("active");
      elements.bookmarkToggle.setAttribute("aria-expanded", "false");
    }
    if (except !== "more") {
      elements.morePopover.hidden = true;
      elements.moreToggle.classList.remove("active");
      elements.moreToggle.setAttribute("aria-expanded", "false");
    }
  }

  function togglePopover(kind) {
    const isBookmark = kind === "bookmark";
    const popover = isBookmark ? elements.bookmarkPopover : elements.morePopover;
    const button = isBookmark ? elements.bookmarkToggle : elements.moreToggle;
    const willOpen = popover.hidden;
    closePopovers(kind);
    popover.hidden = !willOpen;
    button.classList.toggle("active", willOpen);
    button.setAttribute("aria-expanded", String(willOpen));
    if (willOpen) {
      setToolbarToolsOpen(true);
      setSearchOpen(false);
      if (isBookmark) {
        renderBookmarks();
        window.setTimeout(() => elements.bookmarkTitle.focus(), 0);
      }
    }
  }

  function renderBookmarks() {
    const page = currentPage();
    elements.bookmarkTitle.value = page.bookmark;
    elements.removeBookmark.hidden = !page.bookmark;
    const bookmarked = state.pages
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => item.bookmark);

    elements.bookmarkList.replaceChildren();
    if (!bookmarked.length) {
      const empty = document.createElement("div");
      empty.className = "bookmark-empty";
      empty.textContent = tr("noBookmarks");
      elements.bookmarkList.append(empty);
      return;
    }

    bookmarked.forEach(({ item, index }) => {
      const button = document.createElement("button");
      button.className = `bookmark-item${index === state.current ? " current" : ""}`;
      button.type = "button";
      button.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#icon-bookmark"></use></svg><span></span><small>${index + 1}</small>`;
      button.querySelector("span").textContent = item.bookmark;
      button.addEventListener("click", () => goToPage(index));
      elements.bookmarkList.append(button);
    });
  }

  function saveBookmark(event) {
    event.preventDefault();
    const title = elements.bookmarkTitle.value.trim();
    if (!title) {
      showToast(tr("enterBookmark"));
      elements.bookmarkTitle.focus();
      return;
    }
    currentPage().bookmark = title.slice(0, 80);
    renderBookmarks();
    persist(true);
    showToast(tr("bookmarkSaved"));
  }

  function removeBookmark() {
    currentPage().bookmark = "";
    renderBookmarks();
    persist(true);
    showToast(tr("bookmarkRemoved"));
  }

  function cycleFont() {
    state.fontIndex = (state.fontIndex + 1) % FONT_OPTIONS.length;
    applyFont();
    persist(true);
    showToast(tr("fontChanged", { font: FONT_OPTIONS[state.fontIndex].names[state.language] }));
  }

  function download(filename, content, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 500);
  }

  function exportNotes() {
    persist(true);
    const stamp = new Date().toISOString().slice(0, 10);
    download(`wpad-plus-backup-${stamp}.json`, JSON.stringify(state, null, 2), "application/json;charset=utf-8");
    showToast(tr("backupCreated"));
    closePopovers();
  }

  function exportCurrentText() {
    const title = currentPage().bookmark || tr("pageFile", { page: state.current + 1 });
    const safeTitle = title.replace(/[\\/:*?\"<>|]+/g, "-").slice(0, 60);
    download(`${safeTitle}.txt`, currentPage().text, "text/plain;charset=utf-8");
    showToast(tr("pageSavedText"));
    closePopovers();
  }

  async function importNotes(file) {
    if (!file) return;
    try {
      const content = await file.text();
      const parsed = JSON.parse(content);
      if (!parsed || !Array.isArray(parsed.pages) || parsed.pages.length === 0) throw new Error("Invalid Wpad+ backup");
      const imported = normalizeState(parsed);
      if (!window.confirm(tr("replaceImport", { count: imported.pages.length, pages: pluralizePages(imported.pages.length) }))) return;
      state = imported;
      histories.clear();
      applyLanguage();
      applyWindowRect();
      render();
      persist(true);
      closePopovers();
      showToast(tr("backupLoaded"));
    } catch (error) {
      showToast(tr("invalidBackup"));
    } finally {
      elements.importFile.value = "";
    }
  }

  function showToast(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => elements.toast.classList.remove("show"), 2200);
  }

  function applyWindowRect() {
    if (window.innerWidth <= 520 || !state.windowRect) return;
    const rect = state.windowRect;
    const width = Math.min(Math.max(Number(rect.width), 560), window.innerWidth - 20);
    const height = Math.min(Math.max(Number(rect.height), 360), window.innerHeight - 20);
    const left = Math.min(Math.max(Number(rect.left), 10), window.innerWidth - width - 10);
    const top = Math.min(Math.max(Number(rect.top), 10), window.innerHeight - height - 10);
    Object.assign(elements.window.style, {
      transform: "none",
      left: `${left}px`,
      top: `${top}px`,
      width: `${width}px`,
      height: `${height}px`
    });
  }

  function saveWindowRect() {
    if (window.innerWidth <= 520 || elements.window.classList.contains("fullscreen")) return;
    const rect = elements.window.getBoundingClientRect();
    state.windowRect = { left: rect.left, top: rect.top, width: rect.width, height: rect.height };
    persist(false);
  }

  function resetWindowRect() {
    state.windowRect = null;
    ["left", "top", "width", "height"].forEach((property) => elements.window.style.removeProperty(property));
    elements.window.style.transform = "translate(-50%, -50%)";
    persist(true);
    closePopovers();
    showToast(tr("windowReset"));
  }

  function initDrag() {
    if (document.body.classList.contains("extension-shell")) return;
    let drag = null;

    elements.dragHandle.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || event.target.closest("button, input") || window.innerWidth <= 520) return;
      const rect = elements.window.getBoundingClientRect();
      drag = { dx: event.clientX - rect.left, dy: event.clientY - rect.top, width: rect.width, height: rect.height };
      Object.assign(elements.window.style, {
        transform: "none",
        left: `${rect.left}px`,
        top: `${rect.top}px`,
        width: `${rect.width}px`,
        height: `${rect.height}px`
      });
      elements.dragHandle.classList.add("dragging");
      elements.dragHandle.setPointerCapture(event.pointerId);
    });

    elements.dragHandle.addEventListener("pointermove", (event) => {
      if (!drag) return;
      const left = Math.min(Math.max(event.clientX - drag.dx, 6), window.innerWidth - drag.width - 6);
      const top = Math.min(Math.max(event.clientY - drag.dy, 6), window.innerHeight - 64);
      elements.window.style.left = `${left}px`;
      elements.window.style.top = `${top}px`;
    });

    const stopDrag = () => {
      if (!drag) return;
      drag = null;
      elements.dragHandle.classList.remove("dragging");
      saveWindowRect();
    };
    elements.dragHandle.addEventListener("pointerup", stopDrag);
    elements.dragHandle.addEventListener("pointercancel", stopDrag);

    if ("ResizeObserver" in window) {
      let ready = false;
      const observer = new ResizeObserver(() => {
        if (ready) saveWindowRect();
        ready = true;
      });
      observer.observe(elements.window);
    }
  }

  function openPageDialog() {
    elements.pageDialogHint.textContent = tr("availablePages", { total: state.pages.length });
    elements.pageNumberInput.max = String(state.pages.length);
    elements.pageNumberInput.value = String(state.current + 1);
    if (typeof elements.pageDialog.showModal === "function") {
      elements.pageDialog.showModal();
      window.setTimeout(() => elements.pageNumberInput.select(), 0);
    } else {
      const answer = window.prompt(elements.pageDialogHint, String(state.current + 1));
      if (answer !== null) goToPage(Number(answer) - 1);
    }
  }

  function handleDialogSubmit(event) {
    event.preventDefault();
    const page = Number(elements.pageNumberInput.value);
    if (!Number.isInteger(page) || page < 1 || page > state.pages.length) {
      elements.pageDialogHint.textContent = tr("enterRange", { total: state.pages.length });
      return;
    }
    elements.pageDialog.close();
    goToPage(page - 1);
  }

  function handleKeyboard(event) {
    const mod = event.metaKey || event.ctrlKey;
    if (mod && event.key.toLowerCase() === "f") {
      event.preventDefault();
      setSearchOpen(true);
    } else if (mod && event.key.toLowerCase() === "n") {
      event.preventDefault();
      addPage(event.shiftKey);
    } else if (mod && event.key.toLowerCase() === "s") {
      event.preventDefault();
      persist(true);
      showToast(tr("allSaved"));
    } else if (mod && event.key.toLowerCase() === "b") {
      event.preventDefault();
      togglePopover("bookmark");
    } else if (mod && event.key.toLowerCase() === "z" && event.shiftKey) {
      event.preventDefault();
      redo();
    } else if (mod && event.key.toLowerCase() === "z") {
      event.preventDefault();
      undo();
    } else if (event.altKey && event.key === "ArrowLeft") {
      event.preventDefault();
      if (event.shiftKey) moveCurrent(state.current - 1);
      else goToPage(state.current - 1);
    } else if (event.altKey && event.key === "ArrowRight") {
      event.preventDefault();
      if (event.shiftKey) moveCurrent(state.current + 1);
      else goToPage(state.current + 1);
    } else if (event.key === "Escape") {
      if (!elements.bookmarkPopover.hidden || !elements.morePopover.hidden) closePopovers();
      else if (!elements.searchPanel.hidden) setSearchOpen(false);
      else if (elements.dragHandle.classList.contains("tools-open")) setToolbarToolsOpen(false);
    }
  }

  elements.editor.addEventListener("input", () => setCurrentText(elements.editor.value));
  elements.newPage.addEventListener("click", (event) => addPage(event.shiftKey));
  elements.deletePage.addEventListener("click", deleteCurrentPage);
  elements.undo.addEventListener("click", undo);
  elements.redo.addEventListener("click", redo);
  elements.first.addEventListener("click", (event) => navigateWithShift(event, 0, 0));
  elements.previous.addEventListener("click", (event) => navigateWithShift(event, state.current - 1, state.current - 1));
  elements.next.addEventListener("click", (event) => navigateWithShift(event, state.current + 1, state.current + 1));
  elements.last.addEventListener("click", (event) => navigateWithShift(event, state.pages.length - 1, state.pages.length - 1));
  elements.pageCounter.addEventListener("click", openPageDialog);
  elements.toolbarExpand.addEventListener("click", () => {
    setToolbarToolsOpen(!elements.dragHandle.classList.contains("tools-open"));
  });
  elements.searchToggle.addEventListener("click", () => setSearchOpen(elements.searchPanel.hidden));
  elements.searchClose.addEventListener("click", () => setSearchOpen(false));
  elements.searchInput.addEventListener("input", updateSearchCount);
  elements.searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); findNext(); }
  });
  elements.searchNext.addEventListener("click", findNext);
  elements.bookmarkToggle.addEventListener("click", () => togglePopover("bookmark"));
  elements.bookmarkClose.addEventListener("click", closePopovers);
  elements.bookmarkForm.addEventListener("submit", saveBookmark);
  elements.removeBookmark.addEventListener("click", removeBookmark);
  elements.moreToggle.addEventListener("click", () => togglePopover("more"));
  elements.fontCycle.addEventListener("click", cycleFont);
  elements.exportNotes.addEventListener("click", exportNotes);
  elements.exportText.addEventListener("click", exportCurrentText);
  elements.importNotes.addEventListener("click", () => elements.importFile.click());
  elements.importFile.addEventListener("change", () => importNotes(elements.importFile.files[0]));
  elements.languageSelect.addEventListener("change", () => changeLanguage(elements.languageSelect.value));
  elements.resetPosition.addEventListener("click", resetWindowRect);
  elements.pageDialogForm.addEventListener("submit", handleDialogSubmit);
  elements.pageDialogCancel.addEventListener("click", () => elements.pageDialog.close());
  document.addEventListener("keydown", handleKeyboard);
  document.addEventListener("pointerdown", (event) => {
    if (!event.target.closest(".popover, #bookmarkToggle, #moreToggle")) closePopovers();
  });
  window.addEventListener("beforeunload", () => persist(true));
  window.addEventListener("resize", () => {
    if (window.innerWidth > 520) applyWindowRect();
  });

  applyWindowRect();
  initDrag();
  applyLanguage();
  render();
  persist(true);
}());
