"use strict";

function enableActionButton() {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error("Wpad+: не удалось настроить боковую панель", error));
}

enableActionButton();
chrome.runtime.onInstalled.addListener(enableActionButton);
chrome.runtime.onStartup.addListener(enableActionButton);
